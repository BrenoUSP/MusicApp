# Musication
An app that teaches from Music Instruments and Music Genres to Music Theory.
