Essa pasta irá conter todos os arquivos
referentes ao aplicativo para Android
utilizando de Android Studio.