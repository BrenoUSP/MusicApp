package efestus.musication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class preteste_genmus_12 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preteste_genmus_12);
    }
}
